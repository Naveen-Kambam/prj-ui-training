import "../styles/main.scss";

const BODY = document.getElementsByTagName("body");
const CONTAINER = document.getElementById("container");
