var something = document.getElementById('navbar-toggler');

something.style.cursor = 'pointer';
something.onclick = function() {
    document.getElementsByClassName('navbar-nav').addClass('');
};

var something = document.getElementById('navbar-toggler');

something.style.cursor = 'pointer';
something.onclick = function() {
    document.getElementsByClassName('navbar-nav').addClass('');
};